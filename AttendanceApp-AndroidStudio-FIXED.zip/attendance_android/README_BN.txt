Attendance App - Android Studio Project

এই project আপনার Netlify Attendance App-কে WebView-এর মাধ্যমে Android App হিসেবে চালায়।

Target website:
https://tranquil-cupcake-5491f0.netlify.app/

যা আছে:
- WebView
- GPS/Location permission + geolocation callback
- Camera permission
- ছবি upload/camera chooser
- Internet check
- Pull to refresh
- Android back button handling
- APK build করার জন্য Gradle project structure

Android Studio-তে খোলার নিয়ম:
1. ZIP extract করুন।
2. Android Studio > Open > extracted AttendanceApp folder নির্বাচন করুন।
3. Gradle Sync শেষ হতে দিন।
4. Build > Build APK(s) নির্বাচন করুন।

নোট: প্রথমবার Android Studio প্রয়োজনীয় Android SDK/Gradle dependencies ডাউনলোড করতে পারে।
