package com.attendance.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.view.View
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var errorLayout: View
    private lateinit var btnRetry: Button
    private lateinit var tvErrorMessage: TextView

    private val webAppUrl = "https://tranquil-cupcake-5491f0.netlify.app/"

    private var pendingGeoOrigin: String? = null
    private var pendingGeoCallback: GeolocationPermissions.Callback? = null
    private var pendingWebPermissionRequest: PermissionRequest? = null
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null
    private var cameraPhotoUri: Uri? = null

    private lateinit var permissionLauncher: ActivityResultLauncher<Array<String>>
    private lateinit var filePickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
        setupLaunchers()
        setupBackButton()
        setupWebView()
        loadWebsite()
    }

    private fun initViews() {
        webView = findViewById(R.id.webView)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)
        progressBar = findViewById(R.id.progressBar)
        errorLayout = findViewById(R.id.errorLayout)
        btnRetry = findViewById(R.id.btnRetry)
        tvErrorMessage = findViewById(R.id.tvErrorMessage)

        swipeRefreshLayout.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.primary_accent),
            ContextCompat.getColor(this, R.color.primary_dark)
        )
        swipeRefreshLayout.setOnRefreshListener {
            if (isNetworkAvailable()) webView.reload()
            else {
                swipeRefreshLayout.isRefreshing = false
                showErrorView("ইন্টারনেট সংযোগ নেই। দয়া করে মোবাইল ডাটা বা Wi‑Fi চালু করুন।")
            }
        }
        btnRetry.setOnClickListener { loadWebsite() }
    }

    private fun setupLaunchers() {
        permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            val locationGranted = hasLocationPermission()
            val cameraGranted = hasCameraPermission()

            pendingGeoCallback?.invoke(pendingGeoOrigin, locationGranted, false)
            pendingGeoCallback = null
            pendingGeoOrigin = null

            pendingWebPermissionRequest?.let { request ->
                if (cameraGranted) request.grant(request.resources) else request.deny()
            }
            pendingWebPermissionRequest = null

            if (pendingFileCallback != null) {
                if (cameraGranted) showFileChooserInternal()
                else finishFileSelection(null)
            }
        }

        filePickerLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode != RESULT_OK || result.data == null) {
                finishFileSelection(null)
                return@registerForActivityResult
            }
            val data = result.data!!
            val clip = data.clipData
            if (clip != null) {
                val uris = Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                finishFileSelection(uris)
            } else {
                finishFileSelection(data.data?.let { arrayOf(it) })
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadsImagesAutomatically = true
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.setSupportMultipleWindows(false)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.setGeolocationEnabled(true)
        @Suppress("DEPRECATION")
        settings.setGeolocationDatabasePath(filesDir.path)
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.userAgentString = settings.userAgentString + " AttendanceAppMobile/1.0"

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progressBar.visibility = View.GONE
                swipeRefreshLayout.isRefreshing = false
                hideErrorView()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true && !isNetworkAvailable()) {
                    showErrorView("ইন্টারনেট সংযোগ নেই। পেজটি লোড করা সম্ভব হচ্ছে না।")
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("whatsapp:")) {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        .onFailure { Toast.makeText(this@MainActivity, "অ্যাকশন সম্পন্ন করা যায়নি", Toast.LENGTH_SHORT).show() }
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                if (hasLocationPermission()) callback?.invoke(origin, true, false)
                else {
                    pendingGeoOrigin = origin
                    pendingGeoCallback = callback
                    permissionLauncher.launch(arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ))
                }
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                if (request == null) return
                val cameraRequested = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                if (!cameraRequested || hasCameraPermission()) {
                    request.grant(request.resources)
                } else {
                    pendingWebPermissionRequest = request
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                }
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                if (!hasCameraPermission()) {
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                } else {
                    showFileChooserInternal()
                }
                return true
            }
        }
    }

    private fun showFileChooserInternal() {
        val callback = pendingFileCallback ?: return
        try {
            val photoFile = createImageFile()
            cameraPhotoUri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
            val captureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val galleryIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            }
            val chooser = Intent.createChooser(galleryIntent, "ছবি নির্বাচন বা ক্যামেরা চালু করুন")
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(captureIntent))
            filePickerLauncher.launch(chooser)
        } catch (_: Exception) {
            callback.onReceiveValue(null)
            pendingFileCallback = null
        }
    }

    private fun finishFileSelection(uris: Array<Uri>?) {
        pendingFileCallback?.onReceiveValue(uris)
        pendingFileCallback = null
        cameraPhotoUri = null
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: cacheDir
        return File.createTempFile("ATTENDANCE_${stamp}_", ".jpg", dir)
    }

    private fun setupBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else showExitDialog()
            }
        })
    }

    private fun showExitDialog() {
        AlertDialog.Builder(this)
            .setTitle("অ্যাপ বন্ধ করুন")
            .setMessage("আপনি কি Attendance App থেকে বের হতে চান?")
            .setPositiveButton("হ্যাঁ") { _, _ -> finish() }
            .setNegativeButton("না", null)
            .show()
    }

    private fun hasCameraPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun loadWebsite() {
        if (isNetworkAvailable()) {
            hideErrorView()
            webView.loadUrl(webAppUrl)
        } else showErrorView("ইন্টারনেট সংযোগ নেই। দয়া করে মোবাইল ডাটা বা Wi‑Fi চালু করুন।")
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        }
        @Suppress("DEPRECATION")
        return cm.activeNetworkInfo?.isConnected == true
    }

    private fun showErrorView(message: String) {
        tvErrorMessage.text = message
        errorLayout.visibility = View.VISIBLE
        webView.visibility = View.GONE
        progressBar.visibility = View.GONE
    }

    private fun hideErrorView() {
        errorLayout.visibility = View.GONE
        webView.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        pendingFileCallback?.onReceiveValue(null)
        pendingFileCallback = null
        pendingWebPermissionRequest?.deny()
        pendingWebPermissionRequest = null
        webView.destroy()
        super.onDestroy()
    }
}
