# Keep WebView JavaScript Interfaces and ChromeClients
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep WebKit and Geolocation Callbacks
-keepclassmembers class * extends android.webkit.WebChromeClient {
    public void onGeolocationPermissionsShowPrompt(...);
    public void onPermissionRequest(...);
    public boolean onShowFileChooser(...);
}

-keepclassmembers class * extends android.webkit.WebViewClient {
    public void onReceivedError(...);
    public boolean shouldOverrideUrlLoading(...);
}

# Keep Data Models
-keepattributes *Annotation*
-dontwarn android.webkit.**